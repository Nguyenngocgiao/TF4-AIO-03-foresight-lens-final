# Role-based Roadmap V3 Deep — Clean Summary

- Role có file V3 exact: **30/30**
- Tổng slide trong bản clean: **2258**
- Missing exact V3: **Không có**

| # | Roadmap | Số slide | File |
|---:|---|---:|---|
| 1 | Frontend | 84 | `frontend-roadmap-learning-v3-deep.html` |
| 2 | Backend | 105 | `backend-roadmap-learning-v3-deep.html` |
| 3 | Full Stack | 58 | `fullstack-roadmap-learning-v3-deep.html` |
| 4 | DevOps | 59 | `devops-roadmap-learning-v3-deep.html` |
| 5 | DevSecOps | 61 | `devsecops-roadmap-learning-v3-deep.html` |
| 6 | Data Analyst | 62 | `data-analyst-roadmap-learning-v3-deep.html` |
| 7 | AI Engineer | 67 | `ai-engineer-roadmap-learning-v3-deep.html` |
| 8 | AI and Data Scientist | 69 | `ai-data-scientist-roadmap-learning-v3-deep.html` |
| 9 | Data Engineer | 69 | `data-engineer-roadmap-learning-v3-deep.html` |
| 10 | Android | 67 | `android-developer-roadmap-learning-v3-deep.html` |
| 11 | Machine Learning | 65 | `machine-learning-roadmap-learning-v3-deep.html` |
| 12 | PostgreSQL | 74 | `postgresql-dba-roadmap-learning-v3-deep.html` |
| 13 | iOS | 69 | `ios-developer-roadmap-learning-v3-deep.html` |
| 14 | Blockchain | 76 | `blockchain-developer-roadmap-learning-v3-deep-v2.html` |
| 15 | QA | 77 | `qa-engineer-roadmap-learning-v3-deep-v2.html` |
| 16 | Software Architect | 89 | `software-architect-roadmap-learning-v3-deep.html` |
| 17 | API Design | 87 | `api-design-roadmap-learning-v3-deep.html` |
| 18 | Cyber Security | 70 | `cyber-security-roadmap-learning-v3-deep.html` |
| 19 | UX Design | 77 | `ux-design-roadmap-learning-v3-deep.html` |
| 20 | Technical Writer | 79 | `technical-writer-roadmap-learning-v3-deep.html` |
| 21 | Game Developer | 78 | `game-developer-roadmap-learning-v3-deep.html` |
| 22 | Server Side Game Developer | 77 | `server-side-game-developer-roadmap-learning-v3-deep.html` |
| 23 | MLOps | 78 | `mlops-roadmap-learning-v3-deep.html` |
| 24 | Product Manager | 81 | `product-manager-roadmap-learning-v3-deep.html` |
| 25 | Engineering Manager | 83 | `engineering-manager-roadmap-learning-v3-deep-v2.html` |
| 26 | Developer Relations | 73 | `developer-relations-roadmap-learning-v3-deep-v2.html` |
| 27 | BI Analyst | 79 | `bi-analyst-roadmap-learning-v3-deep.html` |
| 28 | AI Red Teaming | 80 | `ai-red-teaming-roadmap-learning-v3-deep.html` |
| 29 | Network Engineer | 85 | `network-engineer-roadmap-learning-v3-deep.html` |
| 30 | Forward Deployed Engineer | 80 | `forward-deployed-engineer-roadmap-learning-v3-deep.html` |
