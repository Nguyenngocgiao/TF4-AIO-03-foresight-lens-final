# Production DevOps Component Slide Pack

Generated: 2026-06-15

Total decks: 34

| Category | Component | File | Purpose |
|---|---|---|---|
| Observability | Prometheus | `prometheus-production-devops-component-slides.html` | time-series metrics + PromQL alerting foundation |
| Observability | Grafana | `grafana-production-devops-component-slides.html` | dashboards, explore, alert visualization |
| Observability | Loki | `loki-production-devops-component-slides.html` | cost-efficient log aggregation with labels |
| Observability | Tempo | `tempo-production-devops-component-slides.html` | distributed tracing backend |
| Observability | Alertmanager | `alertmanager-production-devops-component-slides.html` | alert routing, grouping, inhibition, silencing |
| Observability | OpenTelemetry Collector | `opentelemetry-collector-production-devops-component-slides.html` | vendor-neutral telemetry pipeline |
| Observability | Fluent Bit | `fluent-bit-production-devops-component-slides.html` | lightweight log/telemetry forwarder |
| Observability | Jaeger | `jaeger-production-devops-component-slides.html` | distributed tracing platform |
| Observability | Thanos | `thanos-production-devops-component-slides.html` | global query + long-term storage for Prometheus |
| Observability | Mimir | `mimir-production-devops-component-slides.html` | horizontally scalable Prometheus-compatible metrics backend |
| Observability | Elasticsearch | `elasticsearch-production-devops-component-slides.html` | search and analytics engine |
| Observability | OpenSearch | `opensearch-production-devops-component-slides.html` | open-source search, logs and analytics suite |
| Observability | Kibana | `kibana-production-devops-component-slides.html` | Elasticsearch visualization and exploration UI |
| CI/CD | GitHub Actions | `github-actions-production-devops-component-slides.html` | repository-native CI/CD automation |
| CI/CD | GitLab CI/CD | `gitlab-ci-cd-production-devops-component-slides.html` | pipeline automation with runners |
| CI/CD | Jenkins | `jenkins-production-devops-component-slides.html` | extensible automation server |
| GitOps | Argo CD | `argo-cd-production-devops-component-slides.html` | declarative GitOps CD for Kubernetes |
| GitOps | Flux CD | `flux-cd-production-devops-component-slides.html` | GitOps toolkit for Kubernetes |
| Kubernetes Delivery | Helm | `helm-production-devops-component-slides.html` | Kubernetes package manager |
| Kubernetes Delivery | Kustomize | `kustomize-production-devops-component-slides.html` | template-free Kubernetes configuration overlays |
| Kubernetes Platform | NGINX Ingress Controller | `nginx-ingress-controller-production-devops-component-slides.html` | Kubernetes ingress traffic routing |
| Kubernetes Platform | Traefik | `traefik-production-devops-component-slides.html` | cloud-native ingress and reverse proxy |
| Service Mesh | Istio | `istio-production-devops-component-slides.html` | service mesh: traffic, security, observability |
| Service Mesh | Linkerd | `linkerd-production-devops-component-slides.html` | lightweight service mesh |
| Security | HashiCorp Vault | `hashicorp-vault-production-devops-component-slides.html` | centralized secrets and encryption management |
| Security | External Secrets Operator | `external-secrets-operator-production-devops-component-slides.html` | sync external secret stores to Kubernetes secrets |
| Security | cert-manager | `cert-manager-production-devops-component-slides.html` | Kubernetes certificate automation |
| Security | Trivy | `trivy-production-devops-component-slides.html` | vulnerability and misconfiguration scanner |
| Security | SonarQube | `sonarqube-production-devops-component-slides.html` | static analysis and quality gates |
| Artifact | Harbor | `harbor-production-devops-component-slides.html` | cloud-native artifact registry |
| Artifact | Nexus Repository | `nexus-repository-production-devops-component-slides.html` | binary artifact repository manager |
| Messaging | Kafka | `kafka-production-devops-component-slides.html` | distributed event streaming platform |
| Messaging | RabbitMQ | `rabbitmq-production-devops-component-slides.html` | message broker and work queues |
| Cache | Redis | `redis-production-devops-component-slides.html` | in-memory data structure store |